<div class="tc-step <?php echo esc_attr( $args['slug'] ); ?>">
	<?php echo $args['html']; ?>
</div>
